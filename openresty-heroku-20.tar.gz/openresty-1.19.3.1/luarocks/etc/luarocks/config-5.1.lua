-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/app/openresty-1.19.3.1/luarocks" };
}
lua_interpreter = "luajit";
variables = {
   LUA_DIR = "/app/openresty-1.19.3.1/luajit";
   LUA_BINDIR = "/app/openresty-1.19.3.1/luajit/bin";
}
