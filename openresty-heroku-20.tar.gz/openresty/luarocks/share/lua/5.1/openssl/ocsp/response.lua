local ocsp_response = require "_openssl.ocsp.response"

return ocsp_response
